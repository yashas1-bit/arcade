# NYRVELLO — The Independent Arcade

A polished, browser-based mini arcade built with vanilla HTML, CSS, and JavaScript.

**No install. No build step. No account.** Open `index.html` in a modern browser and play.

## Games

- **Neon Drift** — Dodge incoming hazards for as long as possible.
- **Pixel Invaders** — Defend your sector in a compact space shooter.
- **Reflex Rush** — Test your reaction speed across three rounds.

## Features

- Responsive dark/neon arcade dashboard
- Keyboard and pointer/touch controls
- Local high scores and achievements via `localStorage`
- Sound effects with a mute toggle
- Personal records and run statistics
- No external JavaScript libraries or build tools

## Run locally

1. Download or clone this repository.
2. Open `index.html` in Chrome, Edge, Firefox, or another modern browser.
3. Choose a game and play.

Internet is **not required** for gameplay. The page optionally loads Google Fonts; if offline, it falls back to system fonts.

## Controls

| Game | Controls |
|---|---|
| Neon Drift | Left/Right arrows or A/D; tap left/right side on touchscreens |
| Pixel Invaders | Left/Right arrows or A/D; Space to fire; pointer/touch also supported |
| Reflex Rush | Click or tap when the target turns green |

Press `Esc` to close a game.

## Save data

Scores, total runs, and achievements are stored locally in your browser using `localStorage`. They stay on that browser/device and are not uploaded to a server. Clearing browser site data may erase them.

## Deploy on GitHub Pages

1. Create a public GitHub repository named `nyrvello-arcade` (or any name you like).
2. Upload `index.html`, `README.md`, and `LICENSE`.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then save.
6. Wait for GitHub Pages to publish the site. The URL appears in the Pages section.

You can also use Netlify or Cloudflare Pages by deploying the repository as a static site. No build command is needed; publish directory is the repository root.

## Project structure

```text
nyrvello/
├── index.html
├── README.md
└── LICENSE
```

## Tech

- HTML5 Canvas
- CSS3
- Vanilla JavaScript (ES6+)
- Browser `localStorage`
- Web Audio API

## License

MIT — see [LICENSE](LICENSE).
